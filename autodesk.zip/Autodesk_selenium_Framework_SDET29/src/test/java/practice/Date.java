package practice;

import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Date {
	
	@Test
	public void bookflight() throws Throwable
	{
		//WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//step1: mavigate to fipkart
		driver.get("https://www.tripodeal.com/");
		//enter departure date
		driver.findElement(By.id("origin")).sendKeys("BLR");
		//select BLR in suggesstion
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='eac-item']/b[text()='BLR']")).click();
		//enter destination
		driver.findElement(By.id("destination")).sendKeys("DEL");
		//select the destination
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='eac-item']/b[text()='DEL']")).click();
		//select date feb 16 2022
		driver.findElement(By.id("dateNew")).click();
		Thread.sleep(2000);
		String[] caledar=getDate().split(" ");
		String date=caledar[0];
		String month=caledar[1];
		String year=caledar[2];
		driver.findElement(By.xpath("//div[text()='"
				+ "++']"
				+ "/following-sibling::div[text()='2022']"
				+ "/ancestor::div[@class='picker__box']"
				+ "/descendant::div[text()='16']")).click();
		
}
/**
 * returs the current date 
 * @return format dd MMMM  YYYY
 */
public String getDate() {
	SimpleDateFormat format=new SimpleDateFormat("dd MMMM yyyy");
	String date = format.format(new Date());
	return date;
}
public void bookFlightDate(WebDriver driver, String date, String month, String year) {
	int NoOfMonth=12;
	while(NoOfMonth>=0) {
		try {
			driver.findElement(By.xpath("//div[text()='"+month+"']"//December
					+ "/following-sibling::div[text()='"+year+"']"
					+ "/ancestor::div[@class='picker__box']"
					+ "/descendant::div[text()='"+date+"']")).click();//NoSuchElementException
		}
		catch (Exception e) {
			NoOfMonth--;
			driver.findElement(By
					.xpath("//div[@title='Next month' and @aria-controls='dateNew_table']")).click();
		}

	}
}
}
