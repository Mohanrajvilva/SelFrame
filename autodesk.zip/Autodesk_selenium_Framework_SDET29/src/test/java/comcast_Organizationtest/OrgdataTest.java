package comcast_Organizationtest;

import org.testng.annotations.Test;

import Com.crm.GenericLib.Baseclass;
import Com.crm.PomPages.CreateOrganizationPage;
import Com.crm.PomPages.Homepage;
import Com.crm.PomPages.OrganisationPage;

public class OrgdataTest extends Baseclass{

	@Test(groups="smoketest")
	public void createorgdataTest()
	{
		Homepage hp=new Homepage(driver);
		hp.getOrglink().click();
		
		
		/**
		 * Organisationpage
		 */
		OrganisationPage op=new OrganisationPage(driver);
		op.getPlusbtn().click();
		
		CreateOrganizationPage cop=new CreateOrganizationPage(driver);
		
	}
}
