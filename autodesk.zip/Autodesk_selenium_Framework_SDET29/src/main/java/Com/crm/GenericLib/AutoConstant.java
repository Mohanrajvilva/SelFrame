package Com.crm.GenericLib;

public interface AutoConstant {

	String propertyfilepath=".\\src\\test\\resources\\data.properties";
	String excelfilepath=".\\src\\test\\resources\\Book1.xlsx";
}
