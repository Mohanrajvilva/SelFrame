package test;

public class Primeornot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=10;
		int i=2;
		while(n>i)
		{
			if(n%i==0)
			{
				break;
			}
			else
			{
				i++;
			}
		}
			if(n==i)
			{
				System.out.println("prime");
			}
			else
			{
				System.out.println("not a prime");
			}
		}
	}


