package test;

public class tes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		int i,n=5,z=45,sum=0;
//		for(i=n;i<z;i++)
//		{
//			sum+=i;
//			i=i*i;
//		}
//		System.out.println(sum);
		int n = 0,sum=0,i;
		for(i=0;i<n;i++)
		{
			int temp = 0;
			sum=sum+temp;
		}
		if(sum%2==0)
		{
			System.out.println("1");
		}
		else
		{
			System.out.println("0");
		}

	}

}
