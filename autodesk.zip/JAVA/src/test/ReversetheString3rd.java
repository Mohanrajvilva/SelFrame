package test;

public class ReversetheString3rd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="hello";
		String rev="";
		for(int i=s.length()-1;i>=0;i--)
		{
			rev=rev+s.charAt(i);
		}
		System.out.println(rev);

	}

}
