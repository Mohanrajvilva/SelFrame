package test;

public class Reverssethetringcount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Mohanraj";
		char[] str = s.toCharArray();
		int count=0;
		for(char c:str)
		{
			count++;
		}
		for(int i=count-1;i>=0;i--)
		{
			System.out.print(str[i]);
		}

	}

}
