package test;

public class Palindromenum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=101;
		int temp=n;
		int rev=0;
		while(temp>0)
		{
			int dig=temp%10;
			rev=rev*10+dig;
			temp=temp/10;
		}
		if(rev==n)
		{
			System.out.println("palindrome");
		}
		else
		{
			System.out.println("noot a palindrome");
		}
	}

}
