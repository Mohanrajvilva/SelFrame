package group6;

public class Primefromarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {2,3,4,5,6,7,8};
		for (int i = 0; i < a.length; i++) {
			
			int num=a[i];
			int d=2;
			while(num>d)
			{
				if(num%d==0)
				{
					break;
				}
				else
				{
					d++;
				}
			}
		
			if(num==d)
			{
				System.out.println("prime"+num);
			}
			else
			{
				System.out.println("not a prime");
			}
			
			
		}

	}
}


