package group6;

import java.util.HashSet;

public class SwapfirstandLastWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Welcome to tyss company";
		String[] str = s.split(" ");
		
		String str1=str[0];
		str[0]=str[str.length-1];
		str[str.length-1]=str1;
		for (int i = 0; i < str.length; i++) {
			
			System.out.print(str[i]+" ");
			
		}
		
		
	}
	}
