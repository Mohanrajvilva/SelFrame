package group3;

public class SeparateusingAsic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Mohan123@";
		String al=" ",num=" ",sp=" ";
		for (int i = 0; i < s.length(); i++)
		{
			if((s.charAt(i)>=65 &&s.charAt(i)<=90)||(s.charAt(i)>=97&&s.charAt(i)<=122))
			{
				al=al+s.charAt(i);
			}
			else if(s.charAt(i)>=48 &&s.charAt(i)<=57)
			{
				num=num+s.charAt(i);
			}
			else
			{
				sp=sp+s.charAt(i);
			}
		}
		System.out.println("Alphabets--->"+al);
		System.out.println("Numbers--->"+num);
		System.out.println("SpecialCharacters--->"+sp);

	}

}
