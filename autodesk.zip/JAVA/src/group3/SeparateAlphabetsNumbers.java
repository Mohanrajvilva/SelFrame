package group3;
public class SeparateAlphabetsNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Mohan123@";
		String al=" ",num=" ",sp=" ";
		for (int i = 0; i < s.length(); i++)
		{
			if((s.charAt(i)>='A'&&s.charAt(i)<='Z')||(s.charAt(i)>='a'&&s.charAt(i)<='z'))
			{
				al=al+s.charAt(i);
			}
			else if(s.charAt(i)>='0' &&s.charAt(i)<='9')
			{
				num=num+s.charAt(i);
			}
			else
			{
				sp=sp+s.charAt(i);
			}
		}
		System.out.println("Alphabets--->"+al);
		System.out.println("Numbers--->"+num);
		System.out.println("SpecialCharacters--->"+sp);

	}

}
