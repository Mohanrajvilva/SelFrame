package group3;

import java.util.LinkedHashSet;

public class PositionofEachcharacterreverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Tester";
		s=s.toLowerCase();
		
		//Store the each character of each character in set
		LinkedHashSet<Character> set = new LinkedHashSet<Character>();
		for (int i = 0; i < s.length(); i++) 
		{
			set.add(s.charAt(i));
		}
		//compare the each character of each character of set
		for (Character ch : set)//used to read the character from set
		{
			
			for (int i =s.length()-1; i>=0; i--) 
			{
			if(ch==s.charAt(i))
				{
				//step3	
				System.out.println(ch+" "+(i+1));
				break;
				
				}
			}
			}

	}

}
