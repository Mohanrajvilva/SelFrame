package DEMOS;

import java.util.HashSet;

public class OccurenceWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="welcome to india welcome to mandya";
		String[] str = s.split(" ");
		
		HashSet<String>Set = new HashSet<String>();
		for(int i=0;i<str.length;i++)
		{
			Set.add(str[i]);
		}
		for(String word:Set)
		{
			int count=0;
			for(int i=0;i<str.length;i++)
			{
				if(word.equals(str[i]))
				{
					count++;
				}
			}
			if(count>1)
			{
				System.out.println(word+" "+count);	
			}
			
		}
	}

}
