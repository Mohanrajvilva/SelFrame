package group4;
public class Maximumlengthinarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] str= {"hello","all","welcome","abcdefg","to","java"};
		
		String max = str[0];
		for (int i = 0; i < str.length; i++) {
			if(max.length()<str[i].length())
			{
				max=str[i];
			}
		}
		for (int i = 0; i < str.length; i++) {
			if(max.length()==str[i].length())
			{
				System.out.println(str[i]);
			}
		}

	}

}
