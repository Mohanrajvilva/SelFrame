package group4;

public class Minimumlengthinarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] str= {"hello","all","welcome","abcdefg","too","java"};
		
		String min = str[0];
		for (int i = 0; i < str.length; i++) {
			if(min.length()>str[i].length())
			{
				min=str[i];
			}
		}
		for (int i = 0; i < str.length; i++) {
			if(min.length()==str[i].length())
			{
				System.out.println(str[i]);
			}
		}


	}

}
