package group1;
import java.util.HashSet;
public class NumberofOccurence {

	public static void main(String[] args) {
		String s="hello";
		
		//Store the each character of each character in set
		HashSet<Character> set = new HashSet<Character>();
		for (int i = 0; i < s.length(); i++) 
		{
			set.add(s.charAt(i));
		}
		//compare the each character of each character of set
		for (Character ch : set)//used to read the character from set
		{
			int count=0;
			for (int i = 0; i <s.length(); i++) 
			{
			if(ch==s.charAt(i))
				{
				//step3	
				count++;
				}
			}
			//step4:print both character and count
			System.out.println(ch+" "+count);
		}
		
	}

}
