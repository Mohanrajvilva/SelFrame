package group1;
import java.util.LinkedHashSet;
public class RemoveDuplicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="hello";
		
		//Store the each character of each character in set
		LinkedHashSet<Character> set = new LinkedHashSet<Character>();
		for (int i = 0; i < s.length(); i++) 
		{
			set.add(s.charAt(i));
		}
		//print each character of set
		for (Character ch : set) {
			
			System.out.print(ch);
			
		}
		
	}

}
