package BasicPrograms;

public class Nameprint {
	int count=0;
	public static void main(String[] args) {
		Nameprint np=new Nameprint();
		
		
	
	}
	}
