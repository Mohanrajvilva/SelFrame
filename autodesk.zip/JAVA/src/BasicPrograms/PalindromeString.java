package BasicPrograms;
public class PalindromeString {
public static void main(String[] args) {
		String s="dad";
		String rev ="";
		for(int i=s.length()-1;i>=0;i--)
		{
			rev=rev+s.charAt(i);
		}
		if(s.equals(rev)) {
			System.out.println(s+"--------->The given string is palindrome");
		}
		else
		{
			System.out.println(s+"This string is not palindrome");
		}
	}

}
