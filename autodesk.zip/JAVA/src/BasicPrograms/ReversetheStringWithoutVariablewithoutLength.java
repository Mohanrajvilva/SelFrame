package BasicPrograms;
public class ReversetheStringWithoutVariablewithoutLength {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="tyss";
		char[] ch = s.toCharArray();
		int count=0;
		for(char c:ch) {
			count++;
		}
		System.out.println(s.length()+" "+count);
		for(int i=count-1;i>=0;i--)
		{
			System.out.print(ch[i]);
		}
		
	}

}
