package BasicPrograms;

public class forloop {

	public static void main(String[] args) {
		
//		for (int i = 10; i>0; i--) {
//			System.out.println(i);
//			
//		}
//		for (int i =1; i <=10; i++) {
//			
//			System.out.println(i);
//		}
		
//		/**
//		 * Print the string
//		 */
//		String s="Mohan";
//		for (int i = 0; i<=s.length(); i++) {
//		
//		System.out.print(s.charAt(i));	
//		}
		
		
//		/**
//		 * Reverse the string
//		 */
		String sp="tyss";
		for(int i=sp.length()-1;i>=0;i--)
		{
			System.out.print(sp.charAt(i));
		}
		
//		/**
//		 * Printing the string without using length
//		 */
//		String so="testing";
//		char[] arr = so.toCharArray();
//		int count=0;
//		for(char c:arr)
//		{
//			count++;
//		}
//		System.out.println(count);
//		for(int i=count-1; i>=0 ;i--)
//		{
//			System.out.print(arr[i]);
//		}
		
		/**
		 * Running the loop without updation
		 * Runing the loop withour conditon we can run it will take it as true
		 */
		
		String c="testing";
		for(int i=0; ;i++)
		{
			System.out.println(c.charAt(i));
		}
		
		
	
		
		
		

	}

}
