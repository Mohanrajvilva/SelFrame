package BasicPrograms;

import java.util.ArrayList;

public class List {
	
	public static void main(String[] args) {
		
		ArrayList list=new ArrayList<>(); 
		list.add(90);
		list.add(30);
		list.add(20);
		list.add("sdet");
		list.add(null);
		list.add(50);
		list.add(60);
		list.add(70);
		System.out.println(list);
		
		ArrayList l1=new ArrayList<>(list);
		System.out.println(l1);
	}

}
