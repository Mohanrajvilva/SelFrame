package BasicPrograms;

import java.util.HashSet;

public class Set {
	public static void main(String[] args) {
		HashSet set=new HashSet();
		set.add(20);
		set.add(10);
		set.add(20);
		set.add(null);
		set.add(null);
		set.add("mohan");
		
		System.out.println(set);
		
	}

}
