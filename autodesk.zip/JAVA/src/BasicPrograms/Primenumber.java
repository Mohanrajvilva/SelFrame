package BasicPrograms;
public class Primenumber {
public static void main(String[] args) {
		int n=13;
		int i=2;
		while(i<n)
		{
			if(n%i==0)
			{
				break;
			}
			else
			{
				i++;
			}
		}
		if(n==i)
		{
			System.out.println("Prime");
		}
		else
		{
			System.out.println("not prime");
		}
	}
}
