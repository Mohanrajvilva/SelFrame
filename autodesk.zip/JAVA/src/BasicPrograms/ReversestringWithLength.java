package BasicPrograms;

public class ReversestringWithLength {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String sp="tyss";
		for(int i=sp.length()-1;i>=0;i--)
		{
			System.out.print(sp.charAt(i));
		}
	}
}
