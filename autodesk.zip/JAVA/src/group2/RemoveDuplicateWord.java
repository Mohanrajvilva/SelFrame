package group2;
import java.util.LinkedHashSet;
public class RemoveDuplicateWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="welcome to india welcome to mandya";
		String[] str = s.split(" ");
		
		//Store the each character of each character in set
		LinkedHashSet<String> set = new LinkedHashSet<String>();
		for (int i = 0; i < str.length; i++) 
		{
			set.add(str[i]);
		}
		
		for (String word : set)
		{
			System.out.print(word+" ");
		}

	}

}
