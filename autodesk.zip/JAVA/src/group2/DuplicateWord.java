package group2;
import java.util.LinkedHashSet;
public class DuplicateWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="welcome to india welcome to mandya";
		String[] str = s.split(" ");
		
		//Store the each character of each character in set
		LinkedHashSet<String> set = new LinkedHashSet<String>();
		for (int i = 0; i < str.length; i++) 
		{
			set.add(str[i]);
		}
		//compare the each character of each character of set
		for (String word : set)//used to read the character from set
		{
			int count=0;
			for (int i = 0; i <str.length; i++) 
			{
			if(word.equals(str[i]))
				{
				//step3	
				count++;
				}
			}
			//step4:print both character and count
			if(count>1) {
			System.out.println(word+" "+count);
		}
		}
	}

}
