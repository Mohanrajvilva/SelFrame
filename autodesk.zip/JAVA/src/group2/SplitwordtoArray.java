package group2;

public class SplitwordtoArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="welcome to india welcome to mandya";
		String[] str = s.split(" ");
		
		for (int i = 0; i < str.length; i++) {
			
			System.out.print(str[i]+" ");
			 	
		}
	}

}
